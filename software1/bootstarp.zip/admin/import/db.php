<?php
$host = "localhost";
$username = "root";
//$username = "KalidioscopeIndia";
$password = "";
//$password = "Kalidioscope123";
$database = "stockIndia";
//$database = "stockIndia";
$connection = mysql_connect($host, $username, $password);
if (!$connection){
    die("Database Connection Failed " . mysql_error());
}
$select_db = mysql_select_db($database);
if (!$select_db){
    die("Database Selection Failed " . mysql_error());
}
?>