<?php
include 'db.php';
date_default_timezone_set('Asia/Kolkata');
$trn_date = date("Y-m-d H:i:s");
	if(isset($_POST["Import"])){
		echo $filename=$_FILES["file"]["tmp_name"];
		if($_FILES["file"]["size"] > 0){
		  	$file = fopen($filename, "r");
				while(($emapData = fgetcsv($file,10000, ","))!== FALSE){ 
					$check =  mysql_query("select * FROM re_indiaData where itemcode='$emapData[0]'");
					$row = mysql_fetch_array($check);
					$count = mysql_num_rows($check);
					if($count==0){ 
						if($emapData[0] != 'itemcode'){
							date_default_timezone_set('Asia/Kolkata');
							$date = date('Y-m-d H:m:s');
							$ins_query="insert into re_indiaData(`trn_date`, `itemcode`,`description`,`width`,`quantity`,`price`,`country`)values('$trn_date', '$emapData[0]','$emapData[1]','$emapData[2]','$emapData[3]','$emapData[4]','$emapData[5]')";
							$result = mysql_query( $ins_query, $connection );
						}
					}
				}
	        fclose($file);
	        //throws a message if data successfully imported to mysql database from excel file
	       echo header("Location:../view.php");
			//close of connection
			mysql_close($connection); 
		}
	}	
function distance(){
	
	
}	
?>		 