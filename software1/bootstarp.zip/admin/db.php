<?php
$host = "localhost";
$username = "pro";
//$username = "KalidioscopeIndia";
$password = "Apache$$321";
//$password = "Kalidioscope123";
$database = "project";
//$database = "stockIndia";
$connection = mysql_connect($host, $username, $password);
if (!$connection){
    die("Database Connection Failed " . mysql_error());
}
$select_db = mysql_select_db($database);
if (!$select_db){
    die("Database Selection Failed " . mysql_error());
}
?>